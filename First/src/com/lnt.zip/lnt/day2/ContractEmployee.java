package com.lnt.day2;

public class ContractEmployee extends Employee{

    double payPerDay;

    public ContractEmployee(int id, String name, double payPerDay) {
        super(id, name);
        this.payPerDay = payPerDay;
    }

    @Override
    public String toString() {
        return "ContractEmployee [ id=" + id + ", name=" + name   + "payPerDay=" + payPerDay + "]";
    }

    

}
