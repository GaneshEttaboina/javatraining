package com.lnt.day2;

public class EmployeeTest {
    public static void main(String[] args) {
        // Employee employee = new Employee(23, "Rahul");

        Employee regularEmployee = new RegularEmployee(1, "Shubham", 34343);

        Employee contractEmployee = new ContractEmployee(100, "Shaurya", 44545);

        Employee employees [] = {regularEmployee, contractEmployee};

        for(Employee e : employees){
            e.applyLeave();
        }
    }
}
