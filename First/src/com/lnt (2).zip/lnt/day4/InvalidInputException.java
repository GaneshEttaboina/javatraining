package com.lnt.day4;

public class InvalidInputException  extends RuntimeException{
    
    public InvalidInputException(String message){
        super(message);
    }

}
