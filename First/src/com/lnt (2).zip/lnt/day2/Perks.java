package com.lnt.day2;

public interface Perks {
   abstract void mandatoryLeave();
}
