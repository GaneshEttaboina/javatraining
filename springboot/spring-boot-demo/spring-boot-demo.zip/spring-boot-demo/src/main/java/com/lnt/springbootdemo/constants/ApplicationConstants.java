package com.lnt.springbootdemo.constants;

public class ApplicationConstants {

    public static final String ERROR_MSG = "An unknown error occured";
    public static final String SUCCESS_MSG = "Request Successfully processed";

}
