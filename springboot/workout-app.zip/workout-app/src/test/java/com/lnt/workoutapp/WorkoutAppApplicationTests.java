package com.lnt.workoutapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkoutAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
